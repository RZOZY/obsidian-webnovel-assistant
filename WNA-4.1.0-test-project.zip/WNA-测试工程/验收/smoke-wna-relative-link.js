const book = '小说/WNA 标题隶属树测试';
const wna = app.plugins.plugins['web-novel-assistant'];
const command = 'web-novel-assistant:insert-relative-lore-link';
const previousKey = wna.settings.loreQuickLinkShortcut;
const originalOption = wna.settings.enableLoreQuickLink;
const oldLayout = wna.settings.loreBoardLayout;
const oldFile = wna.settings.loreBoardActiveFile;
const oldFormat = app.vault.getConfig('newLinkFormat');
const check = (condition, reason) => { if (!condition) throw Error(reason); };
const wait = async (action, reason) => {
  for (let attempts = 0; attempts < 120; attempts++) {
    const result = await action();
    if (result) return result;
    await new Promise(resolve => setTimeout(resolve, 55));
  }
  throw Error(reason);
};
const change = (input, value) => {
  input.value = value;
  input.dispatchEvent(new Event('input', { bubbles: true }));
};
const key = (value, init = {}) => activeDocument.activeElement.dispatchEvent(new KeyboardEvent('keydown', {
  key: value, code: value, bubbles: true, cancelable: true, ...init
}));
const shortcut = () => key('F10', { altKey: true, shiftKey: true });
const visible = selector => activeDocument.querySelector(selector);
const targetPath = book + '/设定/快捷链接目标.md';
const movedPath = book + '/设定/快捷链接目标更名.md';
const sourcePath = book + '/快捷链接验收.md';
const targetText = '# 连接仓\n\n## 北仓\n\n#### 标记镜\n\n北仓使用两道刻线。\n\n## 南仓\n\n#### 标记镜\n\n南仓使用三道刻线。\n';
const sourceText = '标题和正文快捷链接实机验收。\n\n现场登记：标记镜\n';
check(app.vault.getName() === 'WNA-测试工程' && app.vault.getFileByPath(book + '/设定/潮镜城志.md'), '未进入测试作品');
check(!app.vault.getFileByPath(movedPath), '测试改名路径已占用');
let target = app.vault.getFileByPath(targetPath) ?? await app.vault.create(targetPath, targetText);
const source = app.vault.getFileByPath(sourcePath) ?? await app.vault.create(sourcePath, sourceText);
check(await app.vault.cachedRead(target) === targetText, '目标是非测试笔记');
check((await app.vault.cachedRead(source)).startsWith(sourceText.split('\n')[0]), '来源是非测试笔记');
await wait(() => app.metadataCache.getFileCache(target)?.headings?.length === 5, '目标笔记未索引');
await wna.characterManager.rebuildCache();
const note = app.workspace.getLeavesOfType('markdown').find(leaf => leaf.view.file === source) ?? app.workspace.getLeaf('tab');
let bench, previousSort, editor;
try {
  await note.setViewState({ type: 'markdown', state: { file: sourcePath, mode: 'source', source: true }, active: true });
  await app.workspace.revealLeaf(note);
  editor = await wait(() => note.view.editor, '未打开测试编辑器');
  if (editor.getValue() !== sourceText) editor.setValue(sourceText);
  wna.settings.loreQuickLinkShortcut = 'Alt+Shift+F10';
  editor.setSelection({ line: 2, ch: 5 }, { line: 2, ch: 8 });
  editor.focus();
  wna.settings.enableLoreQuickLink = false;
  shortcut();
  check(!visible('.prompt-input'), '关闭时快捷键仍启动');
  wna.settings.enableLoreQuickLink = true;
  shortcut();
  const query = await wait(() => visible('.prompt-input'), '编辑器快捷键未打开词条搜索');
  check(query.value === '标记镜', '没有使用所选文字');
  const options = await wait(() => {
    const rows = [...activeDocument.querySelectorAll('.prompt-results .suggestion-item')].filter(row => row.textContent.includes('标记镜'));
    return rows.length === 2 && rows;
  }, '同名词条未展示两个候选');
  options.find(row => row.textContent.includes('南仓')).click();
  const wiki = '[[./设定/快捷链接目标#连接仓#南仓#标记镜|标记镜]]';
  check(editor.getLine(2) === '现场登记：' + wiki, '没有替换为正确的相对路径');
  const text = await wait(async () => {
    const value = await app.vault.cachedRead(source);
    return value.includes(wiki) && value;
  }, '新链接没有保存');
  await wait(() => app.metadataCache.getFileCache(source)?.links?.find(link => link.link.startsWith('./设定/快捷链接目标')), 'Obsidian 未索引相对链接');
  check(app.metadataCache.getFirstLinkpathDest('./设定/快捷链接目标', sourcePath) === target, 'Obsidian 无法解析相对链接');
  await app.fileManager.renameFile(target, movedPath);
  const moved = await wait(async () => {
    const data = await app.vault.cachedRead(source);
    return data.includes('快捷链接目标更名#连接仓#南仓#标记镜|标记镜') && data.trim().split('\n').at(-1);
  }, 'Obsidian 改名后未更新相对链接');
  await app.fileManager.renameFile(target, targetPath);
  await wait(() => app.metadataCache.getFileCache(target)?.headings?.length === 5, '恢复名称后未重新索引');
  app.vault.setConfig('newLinkFormat', 'relative');
  await app.fileManager.renameFile(target, movedPath);
  const relativeAfterRename = await wait(async () => {
    const data = await app.vault.cachedRead(source);
    const localTarget = data.split('\n').at(-2)?.match(/\[\[((?:\.\/)?设定\/快捷链接目标更名)#连接仓#南仓#标记镜\|标记镜\]\]/)?.[1];
    return localTarget && app.metadataCache.getFirstLinkpathDest(localTarget, sourcePath) === target && data.trim().split('\n').at(-1);
  }, '相对路径偏好下改名后仍未保留相对链接');
  await app.fileManager.renameFile(target, targetPath);
  app.vault.setConfig('newLinkFormat', oldFormat);
  await wait(() => app.metadataCache.getFileCache(target)?.headings?.length === 5, '恢复名称后未重新索引');

  bench = app.workspace.getLeavesOfType('webnovel-workbench').find(leaf => leaf.view.getState().currentBookPath === book) ?? app.workspace.getLeaf('tab');
  Object.assign(wna.settings, { loreBoardLayout: 'cards', loreBoardActiveFile: targetPath });
  if (bench.view.getViewType() !== 'webnovel-workbench') await bench.setViewState({ type: 'webnovel-workbench', state: { currentBookPath: book }, active: true });
  await app.workspace.revealLeaf(bench);
  await wait(() => typeof bench.view.reloadBoard === 'function', '工作台未加载');
  previousSort = bench.view.sortMode;
  bench.view.sortMode = 'lore';
  await bench.view.reloadBoard();
  const card = await wait(() => [...bench.view.containerEl.querySelectorAll('.wn-lore-file-panel:not([hidden]) .wn-lore-card')].find(el => el.querySelector('.wn-lore-card-body')?.textContent.includes('南仓使用三道刻线')), '没有找到指定卡片');
  card.querySelector('.wn-lore-card-edit-btn').click();
  const body = await wait(() => visible('.wn-edit-lore-modal textarea'), '卡片正文编辑器未打开');
  body.focus();
  body.setSelectionRange(body.value.length, body.value.length);
  shortcut();
  const cardQuery = await wait(() => visible('.prompt-input'), '工作台卡片快捷键未打开搜索');
  change(cardQuery, '回摆潮钟');
  await wait(() => visible('.prompt-results .suggestion-item')?.textContent.includes('回摆潮钟'), '词条输入无候选');
  key('Enter');
  check(body.value.includes('[[./潮历仪器#潮历仪器#回摆潮钟|回摆潮钟]]'), '工作台卡片没有插入相对链接');
  key('Escape');
  return JSON.stringify({ optIn: true, shortcut: true, selectedText: true, duplicateChoice: true, nativeRename: moved, relativeAfterRename,
    bodyEditor: true, relative: text.trim().split('\n').at(-1) });
} finally {
  if (visible('.prompt-input') || visible('.wn-edit-lore-modal')) key('Escape');
  if (target.path === movedPath) await app.fileManager.renameFile(target, targetPath);
  if (app.vault.getConfig('newLinkFormat') !== oldFormat) app.vault.setConfig('newLinkFormat', oldFormat);
  Object.assign(wna.settings, { enableLoreQuickLink: originalOption, loreQuickLinkShortcut: previousKey, loreBoardLayout: oldLayout, loreBoardActiveFile: oldFile });
  if (bench && previousSort) bench.view.sortMode = previousSort;
}
