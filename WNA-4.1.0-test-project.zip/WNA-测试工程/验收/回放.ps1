$ErrorActionPreference = 'Stop'
$vault = 'WNA-测试工程'
$scenarios = @(
    'smoke-wna-multiple-parents.js',
    'smoke-heading-wheel.js',
    'smoke-wna-pr-review.js',
    'smoke-wna-relative-link.js'
)

foreach ($name in $scenarios) {
    $file = (Join-Path $PSScriptRoot $name).Replace('\', '/')
    $pathArgument = $file | ConvertTo-Json -Compress
    $code = '(async()=>{const source=require("node:fs").readFileSync(' + $pathArgument + ',"utf8");const Run=Object.getPrototypeOf(async function(){}).constructor;return await new Run("app",source)(app)})()'
    $result = & Obsidian.com "vault=$vault" eval "code=$code"
    if ($LASTEXITCODE -ne 0 -or ($result -join "`n") -notmatch '=> \{') {
        throw "$name failed: $result"
    }
    "$name $result"
}
