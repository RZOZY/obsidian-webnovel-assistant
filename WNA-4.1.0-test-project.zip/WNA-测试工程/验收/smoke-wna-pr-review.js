const book = '小说/WNA 标题隶属树测试';
const path = book + '/设定/PR走查验收.md';
const wna = app.plugins.plugins['web-novel-assistant'];
const assert = (test, reason) => { if (!test) throw Error(reason); };
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const wait = async (fn, reason) => {
  for (let attempt = 0; attempt < 100; attempt++) {
    const value = await fn();
    if (value) return value;
    await delay(65);
  }
  throw Error(reason);
};
const seed = [
  '# 走查记录', '', '本页仅用于本地验收。', '',
  '## 入港', '', '入港只记录本段正文。', '',
  '### 旧站', '', '旧站只记录本段正文。', '',
  '#### 北线', '', '北线只记录本段正文。', '',
  '##### 标尺', '', '北线标尺的专属正文。', '',
  '###### 行内校准说明', '', '',
  '#### 南线', '', '南线只记录本段正文。', '',
  '##### 标尺', '', '南线标尺的专属正文。', '',
].join('\n');
assert(wna && app.vault.getName() === 'WNA-测试工程' && app.vault.getFileByPath(book + '/设定/潮镜城志.md'), '未进入指定测试库');
let file = app.vault.getFileByPath(path);
if (!file) file = await app.vault.create(path, seed);
assert((await app.vault.cachedRead(file)).startsWith('# 走查记录\n\n本页仅用于本地验收。'), '验收笔记已用于其他内容');
await wait(() => app.metadataCache.getFileCache(file)?.headings?.length >= 8, '未索引测试大纲');
await wna.characterManager.rebuildCache();
const settings = Object.fromEntries(['loreBoardLayout', 'loreBoardActiveFile', 'enableLorePopover'].map(key => [key, wna.settings[key]]));
const note = app.workspace.getLeavesOfType('markdown').find(leaf => leaf.view.file === file) ?? app.workspace.getLeaf('tab');
const modal = selector => [...activeDocument.querySelectorAll(selector)].at(-1);
const change = (input, value) => {
  input.value = value;
  input.dispatchEvent(new input.ownerDocument.defaultView.Event('input', { bubbles: true }));
};
async function pick(button, name, route) {
  button.click();
  const input = await wait(() => modal('.prompt-input'), '未打开目标搜索');
  change(input, name);
  const option = await wait(() => [...input.ownerDocument.querySelectorAll('.prompt-results .suggestion-item')].find(row =>
    row.textContent.includes(name) && (!route || row.querySelector('.suggestion-note')?.textContent.includes(route))), '未定位关系目标');
  option.click();
  assert(button.textContent === name, '目标按钮未显示短名');
}
const suffix = Date.now().toString(36);
const quickLabel = '源码测潮 ' + suffix;
const cardLabel = '卡片校准 ' + suffix;
let graphLeaf;
let priorSort;
let bench;
try {
  await note.setViewState({ type: 'markdown', state: { file: path, mode: 'source', source: true }, active: true });
  await app.workspace.revealLeaf(note);
  const editor = await wait(() => note.view.editor, '未打开源码编辑器');
  editor.setCursor({ line: editor.getValue().split('\n').indexOf('##### 标尺'), ch: 7 });
  editor.focus();
  app.commands.executeCommandById('web-novel-assistant:add-lore-relation');
  const quick = await wait(() => modal('.wn-quick-lore-relation'), '命令未打开关系弹窗');
  change(quick.querySelector('input'), quickLabel);
  await pick([...quick.querySelectorAll('button')].find(button => !button.classList.contains('mod-cta')), '回摆潮钟');
  quick.querySelector('.mod-cta').click();
  await wait(async () => (await app.vault.cachedRead(file)).includes('**' + quickLabel + '**：[['), '源码关系未保存');

  bench = app.workspace.getLeavesOfType('webnovel-workbench').find(leaf => leaf.view.getState().currentBookPath === book) ?? app.workspace.getLeaf('tab');
  Object.assign(wna.settings, { loreBoardLayout: 'cards', loreBoardActiveFile: path });
  if (bench.view.getViewType() !== 'webnovel-workbench') {
    await bench.setViewState({ type: 'webnovel-workbench', state: { currentBookPath: book }, active: true });
  }
  await app.workspace.revealLeaf(bench);
  await wait(() => typeof bench.view.reloadBoard === 'function', '写作工作台未加载');
  priorSort = bench.view.sortMode;
  bench.view.sortMode = 'lore';
  await bench.view.reloadBoard();
  const cards = () => [...bench.view.containerEl.querySelectorAll('.wn-lore-file-panel:not([hidden]) .wn-lore-card')];
  const title = card => card.querySelector('.wn-lore-card-title')?.textContent;
  const body = card => card.querySelector('.wn-lore-card-body')?.textContent.trim();
  await wait(() => cards().filter(card => title(card) === '标尺').length === 2, '同名 H5 卡片缺失');
  assert(body(cards().find(card => title(card) === '北线')) === '北线只记录本段正文。', '父卡片混入子词条内容');
  assert(body(cards().find(card => title(card) === '入港')) === '入港只记录本段正文。', '父卡片正文隔离失效');
  assert(!cards().some(card => ['关系', '行内校准说明'].includes(title(card))), 'H6 被当成词条卡片');
  const southern = cards().find(card => title(card) === '标尺' && body(card)?.includes('南线'));
  assert(southern, '同名卡片的正文串联');
  southern.querySelector('.wn-lore-card-edit-btn').click();
  const edit = await wait(() => modal('.wn-edit-lore-modal'), '未打开卡片编辑');
  const add = await wait(() => [...edit.querySelectorAll('button')].find(button => button.textContent.includes('添加关系')), '卡片无添加关系入口');
  add.click();
  const row = edit.querySelector('.wn-lore-relation-row:last-child');
  change(row.querySelector('input'), cardLabel);
  await pick(row.querySelector('.wn-lore-relation-picker-btn'), '标尺', '北线');
  edit.querySelector('.mod-cta').click();
  const saved = await wait(async () => {
    const value = await app.vault.cachedRead(file);
    return value.includes('**' + cardLabel + '**：[[') && value;
  }, '卡片关系未保存');
  for (const label of [quickLabel, cardLabel]) {
    assert(saved.split('\n').some(line => line.startsWith('**' + label + '**：[[')), '关系格式与旧写法不一致');
  }
  assert(saved.split('\n').filter(line => line === '###### 关系').length === 2, '关系块插入到错误层级');
  assert(saved.includes('###### 行内校准说明'), '普通 H6 被改动');
  await wna.characterManager.rebuildCache();

  graphLeaf = app.workspace.getLeaf('tab');
  wna.settings.enableLorePopover = true;
  await graphLeaf.setViewState({ type: 'webnovel-relation-graph', state: { filePath: path }, active: true });
  await app.workspace.revealLeaf(graphLeaf);
  const graph = await wait(() => graphLeaf.view.graphData?.nodes.some(node => node.heading === '标尺') && graphLeaf.view, '独立图谱未加载');
  await wait(() => graph.engine?.isConverged, '图谱布局未稳定');
  const byId = new Map(graph.graphData.nodes.map(node => [node.id, node]));
  const find = label => graph.graphData.edges.find(edge => edge.type === 'explicit' && edge.label === label);
  const cross = find(quickLabel);
  const same = find(cardLabel);
  assert(byId.get(cross?.source)?.heading === '标尺' && byId.get(cross?.target)?.heading === '回摆潮钟', '源码 H5 跨笔记关系未入图');
  assert(byId.get(same?.source)?.sectionKey.includes('南线') && byId.get(same?.target)?.sectionKey.includes('北线'), '同名词条连线指向错误');
  assert(graph.graphData.edges.some(edge => edge.type === 'explicit' && edge.label === '协作'), '旧三级关系未兼容');
  assert(graph.graphData.edges.some(edge => edge.type === 'hierarchy' && /^(隶属|隸屬|Hierarchy)$/.test(edge.label)), '图谱隶属标签未更新');
  const continuation = graph.graphData.nodes.find(node => node.heading === '北环阀组');
  assert(graph.graphData.edges.some(edge => edge.type === 'hierarchy' && edge.target === continuation?.id
    && byId.get(edge.source)?.heading === '石循检修层'), 'H5 延伸到另一笔记的隶属关系丢失');

  const south = byId.get(same.source);
  const canvas = graph.canvas;
  const rect = canvas.getBoundingClientRect();
  const state = graph.renderState;
  state.scale = 1;
  state.panX = rect.width / 2 - south.x;
  state.panY = rect.height / 2 - south.y;
  graph.render();
  const Mouse = canvas.ownerDocument.defaultView.MouseEvent;
  const point = { clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, bubbles: true };
  canvas.dispatchEvent(new Mouse('mousemove', point));
  assert(state.hoveredNode === south && canvas.style.cursor === 'pointer', '图谱鼠标无法悬停深层同名节点');
  await wait(() => modal('.wn-lore-hover-popover')?.textContent.includes('南线标尺的专属正文。'), '同名图谱悬停预览选错词条');
  canvas.dispatchEvent(new Mouse('mouseleave', point));
  assert(state.hoveredNode === null, '图谱鼠标离开后仍保留高亮');
  const root = graph.graphData.nodes.find(node => node.heading === '走查记录');
  assert(root.descendantCount === 6 && !south.descendantCount, '主要节点的下级统计错误');

  wna.settings.loreBoardLayout = 'graph';
  await app.workspace.revealLeaf(bench);
  await bench.view.reloadBoard();
  const boardCanvas = await wait(() => bench.view.containerEl.querySelector('.wn-lore-graph-canvas'), '工作台图谱未打开');
  const ctx = boardCanvas.getContext('2d');
  const rawClear = ctx.clearRect;
  const rawText = ctx.fillText;
  const rawArc = ctx.arc;
  let frame = new Map();
  let shape;
  ctx.clearRect = function (...args) { frame = new Map(); shape = null; return rawClear.apply(this, args); };
  ctx.arc = function (x, y, radius, ...args) {
    shape = { radius, x, y };
    return rawArc.call(this, x, y, radius, ...args);
  };
  ctx.fillText = function (label, x, y, ...args) {
    if (this.textBaseline === 'top' && shape) {
      const bounds = boardCanvas.getBoundingClientRect();
      const matrix = this.getTransform();
      const project = (px, py) => ({
        clientX: bounds.left + (matrix.a * px + matrix.e) * bounds.width / boardCanvas.width,
        clientY: bounds.top + (matrix.d * py + matrix.f) * bounds.height / boardCanvas.height
      });
      frame.set(label, { radius: shape.radius, alpha: this.globalAlpha,
        point: project(shape.x, shape.y), labelPoint: project(x, y + 5) });
    }
    return rawText.call(this, label, x, y, ...args);
  };
  try {
    const bounds = boardCanvas.getBoundingClientRect();
    const win = boardCanvas.ownerDocument.defaultView;
    const center = { clientX: bounds.left + bounds.width / 2, clientY: bounds.top + bounds.height / 2 };
    for (let step = 0; step < 4; step++) {
      boardCanvas.dispatchEvent(new win.WheelEvent('wheel', { ...center, deltaY: 120, cancelable: true }));
    }
    await wait(() => frame.has('回声闸站') && frame.has('雾光尺') && frame.has('走查记录'), '工作台没有实际画出设定节点');
    await delay(400);
    assert(frame.get('走查记录').radius > frame.get('雾光尺').radius, '画布中的节点未按下级数量放大');
    const station = frame.get('回声闸站');
    boardCanvas.dispatchEvent(new win.MouseEvent('mousemove', station.labelPoint));
    await wait(() => frame.get('回声闸站')?.alpha === 1 && frame.get('北环汐渠')?.alpha === 1
      && frame.get('回摆潮钟')?.alpha === 1 && frame.get('雾光尺')?.alpha < 0.5, '工作台没有高亮悬停词条、隶属邻居和跨笔记关系');
    boardCanvas.dispatchEvent(new win.MouseEvent('mouseleave', station.labelPoint));
    await wait(() => boardCanvas.style.cursor === 'default', '工作台鼠标移出后未清除悬停');
  } finally {
    delete ctx.clearRect;
    delete ctx.fillText;
    delete ctx.arc;
  }
  return JSON.stringify({ cards: true, sourceAndCardRelation: true, sameNameHover: true, workbenchHover: true,
    legacy: true, hierarchy: true, h5Continuation: true, descendantCount: root.descendantCount });
} finally {
  Object.assign(wna.settings, settings);
  if (typeof priorSort === 'string') bench.view.sortMode = priorSort;
  graphLeaf?.detach();
}
