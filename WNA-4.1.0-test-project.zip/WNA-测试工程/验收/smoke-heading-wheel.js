const scope = '小说/WNA 标题隶属树测试';
const path = `${scope}/标题轮盘试用.md`;
const seed = '霜河领\n\n### 旧港\n\n', id = 'web-novel-assistant:open-heading-wheel';
const assert = (condition, description) => { if (!condition) throw Error(description); };
assert(app.vault.getName() === 'WNA-测试工程' && app.vault.getFileByPath(`${scope}/设定/潮镜城志.md`), '目标不是测试作品');
let file = app.vault.getFileByPath(path);
if (!file) file = await app.vault.create(path, seed);
assert(await app.vault.cachedRead(file) === seed, '试用笔记有其他内容，停止测试');
const leaf = app.workspace.getLeavesOfType('markdown').find(item => item.view.file?.path === path) ?? app.workspace.getLeaf('tab');
await leaf.openFile(file, { active: true, state: { mode: 'source' } });
await app.workspace.revealLeaf(leaf);
const editor = leaf.view.editor;
const wna = app.plugins.plugins['web-novel-assistant'];
const hotkeys = app.hotkeyManager;
const originalHotkeys = hotkeys.getHotkeys(id);
const originalOption = wna.settings.enableHeadingWheel;
const wheel = () => document.querySelector('.wn-heading-wheel-modal');
const key = (value, hints = {}) => {
  const event = new KeyboardEvent('keydown', { key: value, code: value, bubbles: true, cancelable: true, composed: true, ...hints });
  document.activeElement.dispatchEvent(event);
  return event;
};
const openWith = value => key(value, { altKey: true, shiftKey: true });
const waitFor = async (predicate, description) => {
  for (let i = 0; i < 25; i++) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw Error(description);
};
try {
  editor.setCursor({ line: 0, ch: 3 });
  editor.focus();
  hotkeys.setHotkeys(id, [{ modifiers: ['Alt', 'Shift'], key: 'F8' }]);
  wna.settings.enableHeadingWheel = false;
  openWith('F8');
  assert(!wheel(), '关闭功能时轮盘仍被唤出');
  wna.settings.enableHeadingWheel = true;
  openWith('F8');
  await waitFor(() => wheel()?.querySelectorAll('button[data-level]').length === 6, '绑定键没有打开六级轮盘');
  const handled = key('6', { code: 'Digit6' });
  await waitFor(() => !wheel(), '主键区的 6 未关闭轮盘');
  assert(handled.defaultPrevented && editor.getLine(0) === '###### 霜河领', '主键区的 6 未设置 H6');
  assert(editor.getCursor().line === 0 && editor.getCursor().ch === 10, '光标没有保留在标题末尾');
  assert(!key('5', { code: 'Digit5' }).defaultPrevented, '轮盘关闭后仍拦截数字');

  hotkeys.setHotkeys(id, [{ modifiers: ['Alt', 'Shift'], key: 'F9' }]);
  editor.setCursor({ line: 2, ch: 4 });
  editor.focus();
  openWith('F8');
  assert(!wheel(), '修改绑定后旧按键仍然打开轮盘');
  openWith('F9');
  await waitFor(() => wheel()?.querySelector('[aria-current=true]')?.getAttribute('data-level') === '3', '新按键或当前标题标记错误');
  key('2', { code: 'Numpad2', location: 3 });
  await waitFor(() => !wheel(), '数字小键盘未关闭轮盘');
  assert(editor.getLine(2) === '## 旧港', '数字小键盘未更换为 H2');

  openWith('F9');
  await waitFor(wheel, '取消前轮盘没有打开');
  key('Escape');
  await waitFor(() => !wheel(), 'Esc 没有关闭轮盘');
  assert(editor.getLine(2) === '## 旧港', '取消时修改了文档');

  openWith('F9');
  await waitFor(wheel, '鼠标测试前轮盘没有打开');
  wheel().querySelector('[data-level="4"]').click();
  assert(!wheel() && editor.getLine(2) === '#### 旧港', '点击轮盘选项未设置 H4');
  assert(editor.getLine(1) === '' && editor.getLine(0) === '###### 霜河领', '修改标题影响了其它行');
  return JSON.stringify({ optIn: true, rebind: true, keyboardDigits: true, keypad: true, click: true, escape: true, restoredEditor: true });
} finally {
  if (wheel()) key('Escape');
  if (originalHotkeys) hotkeys.setHotkeys(id, originalHotkeys);
  else hotkeys.removeHotkeys(id);
  wna.settings.enableHeadingWheel = originalOption;
  if (editor.getValue() !== seed) editor.setValue(seed);
}
