const book = '小说/WNA 标题隶属树测试';
const folder = `${book}/设定`;
const wna = app.plugins.plugins['web-novel-assistant'];
const check = (value, reason) => { if (!value) throw Error(reason); };
const wait = async (callback, reason) => {
  for (let index = 0; index < 80; index++) {
    const result = await callback();
    if (result) return result;
    await new Promise(resolve => setTimeout(resolve, 65));
  }
  throw Error(reason);
};
const source = app.vault.getFileByPath(`${folder}/常驻路径验收.md`);
const multiPath = `${folder}/多重隶属验收.md`;
check(source && wna && app.vault.getName() === 'WNA-测试工程', '测试库、插件或截图中的笔记不存在');
let multi = app.vault.getFileByPath(multiPath);
if (!multi) multi = await app.vault.create(multiPath, [
  '# 多重隶属验收', '', '记录需要两个工序联合验收的设备。', '',
  '## 合验台', '', '既需要潮历校准，也归工团检修。', '',
  '###### 关系', '**上级词条**：[[潮历仪器#潮历仪器#回摆潮钟|回摆潮钟]]、[[行会名册#行会名册#折光工团|折光工团]]',
  '**上级词条**：[[潮历仪器#潮历仪器#回摆潮钟|重复目标]]、[[未知设定#无效目标]]', '',
  '### 复验位', '', '复验时先校准周期。', '',
].join('\n'));
await wait(() => app.metadataCache.getFileCache(multi)?.headings?.some(heading => heading.heading === '合验台'), '新建多父节点示例未索引');
await wna.characterManager.rebuildCache();
const graph = await wna.relationGraphManager.buildGraphData(source, {
  files: wna.characterManager.getEffectiveLoreFiles(book), includeHeadingHierarchy: true, autoLinkMentions: true,
});
const titled = name => graph.nodes.find(node => node.heading === name);
const parents = node => graph.edges.filter(edge => edge.type === 'hierarchy' && edge.target === node.id).map(edge => edge.source);
check(parents(titled('校验镜')).join() === [titled('夜潮工坊').id, titled('回摆潮钟').id].join(), '原示例图谱里的本地或跨笔记上级丢失');
check(parents(titled('合验台')).join() === [titled('多重隶属验收').id, titled('回摆潮钟').id, titled('折光工团').id].join(), '多个上级的有效性或去重不正确');
check(titled('夜潮工坊').descendantCount >= 3, '原图谱下级计数丢失');
check(!graph.edges.some(edge => edge.type === 'explicit' && edge.label === '上级词条'), '把隶属连线重复渲染成普通关系');

const saved = ['loreShowAncestorPath', 'loreAutoShowAncestors', 'loreFoldAncestorPath', 'loreBoardLayout', 'loreBoardActiveFile']
  .map(key => [key, wna.settings[key]]);
const note = app.workspace.getLeavesOfType('markdown').find(leaf => leaf.view.file === source) ?? app.workspace.getLeaf('tab');
const setMode = async (file, mode, sourceMode) => {
  await note.setViewState({ type: 'markdown', state: { file: file.path, mode, source: sourceMode }, active: true });
  await app.workspace.revealLeaf(note);
  await wait(() => note.view.file === file && note.view.getMode() === mode, '视图模式切换未完成');
};
const findRow = heading => [...note.view.containerEl.querySelectorAll(
  (note.view.getMode() === 'preview' ? '.markdown-reading-view' : '.cm-editor') + ' .wn-lore-ancestor-row'
)].find(row =>
  row.previousElementSibling?.textContent.replace(/^#+\s*/, '').trim() === heading
);
const contents = row => [...row.querySelectorAll('.wn-lore-ancestor-text')].map(path => path.textContent);
const expected = ['常驻路径验收 › 夜潮工坊', '潮历仪器 › 回摆潮钟'];
const matches = (row, values) => row && contents(row).join('|') === values.join('|') && row;
try {
  Object.assign(wna.settings, { loreShowAncestorPath: true, loreAutoShowAncestors: true, loreFoldAncestorPath: false });
  app.workspace.trigger('webnovel-workbench-lore-updated');
  await setMode(source, 'source', true);
  await wait(() => matches(findRow('校验镜'), expected), '源码模式未按本笔记优先列出两条路径');
  await setMode(source, 'source', false);
  await wait(() => matches(findRow('候潮镀层'), expected.map(path => path + ' › 校验镜')), '实时预览未继承两条路径');
  await setMode(source, 'preview', false);
  const row = await wait(() => matches(findRow('校验镜'), expected), '阅读模式未显示两条路径');
  check(row.previousElementSibling.tagName === 'H3', '阅读模式路径未紧贴词条标题');
  await setMode(multi, 'source', false);
  await wait(() => matches(findRow('合验台'), ['多重隶属验收', '潮历仪器 › 回摆潮钟', '行会名册 › 折光工团']), '多上级路径少于三条');

  wna.settings.loreFoldAncestorPath = true;
  app.workspace.trigger('webnovel-workbench-lore-updated');
  const folded = await wait(() => findRow('合验台')?.querySelector('.wn-lore-ancestor-dot') && findRow('合验台'), '折叠未生效');
  const dot = folded.querySelector('.wn-lore-ancestor-dot');
  const list = folded.querySelector('.wn-lore-ancestor-list');
  check(folded.querySelectorAll('.wn-lore-ancestor-dot').length === 1 && list.hidden && list.getBoundingClientRect().height === 0, '折叠不是共用一个灰点');
  dot.click();
  check(!list.hidden && contents(folded).length === 3, '灰点没展开全部路径');
  dot.click();
  check(list.hidden, '灰点无法收起');

  const bench = app.workspace.getLeavesOfType('webnovel-workbench').find(leaf => leaf.view.getState().currentBookPath === book)
    ?? app.workspace.getLeaf('tab');
  Object.assign(wna.settings, { loreBoardLayout: 'cards', loreBoardActiveFile: source.path, loreFoldAncestorPath: false });
  if (bench.view.getViewType() !== 'webnovel-workbench') await bench.setViewState({ type: 'webnovel-workbench', state: { currentBookPath: book }, active: true });
  await app.workspace.revealLeaf(bench);
  await wait(() => typeof bench.view.reloadBoard === 'function', '写作工作台未加载');
  bench.view.sortMode = 'lore';
  await bench.view.reloadBoard();
  const card = () => [...bench.view.containerEl.querySelectorAll('.wn-lore-card')].find(el => el.querySelector('.wn-lore-card-title')?.textContent === '校验镜');
  await wait(() => matches(card()?.querySelector('.wn-lore-card-parent'), expected), '设定卡片未显示两条路径');
} finally {
  Object.assign(wna.settings, Object.fromEntries(saved));
  app.workspace.trigger('webnovel-workbench-lore-updated');
  await setMode(source, 'source', false);
}
return JSON.stringify({ source: true, reader: true, descendant: true, cards: true, paths: expected, validParents: 3, foldedBySingleDot: true });
